package goldenTime.command;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import goldenTime.dao.EmrStatusDao;
import goldenTime.dto.EmrRecommendDto;

public class EmergencyRoomRecommendation {
	private EmrStatusDao emrStatusDao; 
    private DecisionTreeModel decisionTreeModel; // 의사결정 트리 모델

    // 생성자
    public EmergencyRoomRecommendation(EmrStatusDao emrStatusDao, DecisionTreeModel decisionTreeModel) {
        this.emrStatusDao = emrStatusDao;
        this.decisionTreeModel = decisionTreeModel;
    }
    
 // 응급실 추천 메서드
    public List<EmrRecommendDto> recommendEmergencyRooms() {
        // DAO를 통해 응급실 데이터 가져오기
        List<EmrRecommendDto> emergencyRooms = emrStatusDao.getAllEmergencyRooms();

        // 의사결정 트리 모델을 사용하여 예측하기
        List<EmrRecommendDto> recommendedRooms = new ArrayList<>();
        for (EmrRecommendDto room : emergencyRooms) {
        	Map<String, Object> roomMap = room.toMap();
        	// 의사결정 트리 모델을 사용하여 방이 적합한지 예측
            boolean isSuitable = decisionTreeModel.predict(roomMap); // 의사결정 트리 모델을 사용하여 예측

            // 적합하다고 예측된 경우, 추천 응급실 목록에 추가
            if (isSuitable) {
                recommendedRooms.add(room);
            }
        }
        return recommendedRooms;
    }
    
}

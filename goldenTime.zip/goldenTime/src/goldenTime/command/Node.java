package goldenTime.command;

import java.util.HashMap;
import java.util.Map;

public class Node {
	private String splitAttribute; //분할에 사용되는 속성
	private boolean isLeaf; //리프 노드인지 여부
	private Object label; //리프 노드인 경우 예측된 레이블
	private Map<Object, Node> children; //자식 노드들
	
	public Node() {
		children = new HashMap<>();
	}
	
	public String getSplitAttribute() {
		return splitAttribute;
	}
	public void setSplitAttribute(String splitAttribute) {
		this.splitAttribute = splitAttribute;
	}
	public boolean isLeaf() {
		return isLeaf;
	}
	public void setLeaf(boolean isLeaf) {
		this.isLeaf = isLeaf;
	}
	public Object getLabel() {
		return label;
	}
	public void setLabel(Object label) {
		this.label = label;
	}
	public void addChild(Object attributeValue, Node childNode) {
        children.put(attributeValue, childNode);
    }

    public Node getChild(Object attributeValue) {
        return children.get(attributeValue);
    }
	
}

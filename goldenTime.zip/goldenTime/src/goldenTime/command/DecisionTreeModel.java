package goldenTime.command;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class DecisionTreeModel {
	private Node rootNode;
	
	public DecisionTreeModel() {
		rootNode = null;
	}
	
	// 데이터셋을 사용하여 결정 트리 모델을 학습
	public void train(List<Map<String, Object>> dataset, String targetAttribute) {
		rootNode = buildDecisionTree(dataset, targetAttribute);
	}
	
	// CART 알고리즘을 사용하여 재귀적으로 결정 트리를 만드는 메서드
    private Node buildDecisionTree(List<Map<String, Object>> dataset, String targetAttribute) {
    	// 기본 경우: 데이터셋이 비어 있거나 모든 인스턴스의 클래스가 같은 경우
        if (dataset.isEmpty() || sameClass(dataset, targetAttribute)) {
            Node leafNode = new Node(); // 리프 노드 생성
            leafNode.setLeaf(true); // 리프 노드로 설정
            leafNode.setLabel(getMostCommonClass(dataset, targetAttribute)); // 가장 일반적인 클래스 레이블 설정
            return leafNode;
        }
        
        //가장 좋은 분할 속성을 찾음
        String bestAttribute = findBestSplitAttribute(dataset, targetAttribute);
        
        // 가장 좋은 속성에 대한 결정 노드 생성
        Node decisionNode = new Node();
        decisionNode.setSplitAttribute(bestAttribute); // 분할 속성 설정
        decisionNode.setLeaf(false); // 리프 노드가 아님

        // 가장 좋은 속성을 기반으로 데이터셋을 분할
        Map<Object, List<Map<String, Object>>> splitData = splitDataset(dataset, bestAttribute);

        // 각 속성 값에 대해 하위 트리를 재귀적으로 만듦
        for (Object attributeValue : splitData.keySet()) {
            Node subtree = buildDecisionTree(splitData.get(attributeValue), targetAttribute);
            decisionNode.addChild(attributeValue, subtree);
        }

        return decisionNode;
    }
        
        //데이터셋의 모든 인스턴스가 같은 클래스를 가지고 있는지 확인하는 메서드
        private boolean sameClass(List<Map<String, Object>> dataset, String targetAttribute) {
            Object firstClass = dataset.get(0).get(targetAttribute);
            for (Map<String, Object> instance : dataset) {
                if (!instance.get(targetAttribute).equals(firstClass)) {
                    return false;
                }
            }
            return true;
        }
        
        // 데이터셋에서 가장 일반적인 클래스 레이블을 가져오는 메서드
        private Object getMostCommonClass(List<Map<String, Object>> dataset, String targetAttribute) {
            Map<Object, Integer> classCounts = new HashMap<>();
            for (Map<String, Object> instance : dataset) {
                Object classLabel = instance.get(targetAttribute);
                classCounts.put(classLabel, classCounts.getOrDefault(classLabel, 0) + 1);
            }
            // 가장 빈번한 클래스 레이블 찾기
            Object mostCommonClass = null;
            int maxCount = 0;
            for (Object classLabel : classCounts.keySet()) {
                if (classCounts.get(classLabel) > maxCount) {
                    maxCount = classCounts.get(classLabel);
                    mostCommonClass = classLabel;
                }
            }
            return mostCommonClass;
        }

        // Gini 불순도를 사용하여 최적의 분할 속성을 찾는 메서드
        private String findBestSplitAttribute(List<Map<String, Object>> dataset, String targetAttribute) {
            double bestGini = Double.POSITIVE_INFINITY;
            String bestAttribute = null;
            
            // 데이터셋의 각 속성을 반복
            for (String attribute : dataset.get(0).keySet()) {
                if (attribute.equals(targetAttribute)) continue; // 타겟 속성은 건너뜀

                // 각 속성에 대한 지니 불순도 계산
                double gini = calculateGini(dataset, attribute, targetAttribute);

                // 현재 속성이 더 낮은 불순도를 가질 때 최적의 속성을 업데이트
                if (gini < bestGini) {
                    bestGini = gini;
                    bestAttribute = attribute;
                }
            }
            return bestAttribute;
        }
        
     // 지니 불순도를 계산하는 메서드
        private double calculateGini(List<Map<String, Object>> dataset, String attribute, String targetAttribute) {
            double gini = 0.0;
            int totalInstances = dataset.size();

            // 속성의 모든 값을 가져옵니다.
            Set<Object> attributeValues = new HashSet<>();
            for (Map<String, Object> instance : dataset) {
                attributeValues.add(instance.get(attribute));
            }

            // 속성 값별로 불순도를 계산합니다.
            for (Object value : attributeValues) {
                List<Map<String, Object>> subset = getSubset(dataset, attribute, value);
                double proportion = (double) subset.size() / totalInstances;

                // 각 값에 대한 클래스의 비율을 계산합니다.
                Map<Object, Integer> classCounts = getClassCounts(subset, targetAttribute);
                double impurity = 1.0;

                // 해당 값의 클래스에 대한 비율을 사용하여 지니 불순도를 계산합니다.
                for (Object classLabel : classCounts.keySet()) {
                    double p = (double) classCounts.get(classLabel) / subset.size();
                    impurity -= p * p;
                }

                // 속성 값별로 가중치를 적용하여 지니 불순도를 계산합니다.
                gini += proportion * impurity;
            }

            return gini;
        }

        // 데이터셋에서 특정 속성 값에 해당하는 하위 집합을 가져오는 메서드
        private List<Map<String, Object>> getSubset(List<Map<String, Object>> dataset, String attribute, Object value) {
            List<Map<String, Object>> subset = new ArrayList<>();
            for (Map<String, Object> instance : dataset) {
                if (instance.get(attribute).equals(value)) {
                    subset.add(instance);
                }
            }
            return subset;
        }

        // 데이터셋에서 클래스 레이블의 개수를 가져오는 메서드
        private Map<Object, Integer> getClassCounts(List<Map<String, Object>> dataset, String targetAttribute) {
            Map<Object, Integer> classCounts = new HashMap<>();
            for (Map<String, Object> instance : dataset) {
                Object classLabel = instance.get(targetAttribute);
                classCounts.put(classLabel, classCounts.getOrDefault(classLabel, 0) + 1);
            }
            return classCounts;
        }

        
        
        

        // 주어진 속성을 기준으로 데이터셋을 분할하는 메서드
        private Map<Object, List<Map<String, Object>>> splitDataset(List<Map<String, Object>> dataset, String attribute) {
            Map<Object, List<Map<String, Object>>> splitData = new HashMap<>();
            for (Map<String, Object> instance : dataset) {
                Object attributeValue = instance.get(attribute);
                if (!splitData.containsKey(attributeValue)) {
                    splitData.put(attributeValue, new ArrayList<>());
                }
                splitData.get(attributeValue).add(instance);
            }
            return splitData;
        }
        
        //새 인스턴스에 대한 예측
        public boolean predict(Map<String, Object> instance) {
        	Object prediction = predictRecursively(instance, rootNode);
        	if(prediction instanceof Boolean) {
        		return (boolean) prediction;        		
        	} else {
        		return false;
        	}
        }
        
        //결정 트리를 재귀적으로 탐색하여 예측하는 메서드
        private Object predictRecursively(Map<String, Object> instance, Node node) {
        	if (node == null || node.getSplitAttribute() == null) {
        		System.out.println("node가 null이거나 분할 속성이 없는 경우");
                return null; 
            }
            if (node.isLeaf()) {
                return node.getLabel();
            }
            Object attributeValue = instance.get(node.getSplitAttribute());
            Node childNode = node.getChild(attributeValue);
            return predictRecursively(instance, childNode);
        }
    
 
}

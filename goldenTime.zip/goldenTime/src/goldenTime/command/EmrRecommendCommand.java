package goldenTime.command;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import goldenTime.dto.EmrRecommendDto;

public class EmrRecommendCommand implements EmrCommand {
	private EmergencyRoomRecommendation emrRecommendation;

    // EmergencyRoomRecommendationCommand 의존성 주입을 위한 생성자
    public EmrRecommendCommand(EmergencyRoomRecommendation emrRecommendation) {
        this.emrRecommendation = emrRecommendation;
    }
    
    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	System.out.println("EmrRecommendCommand");
    	// EmergencyRoomRecommendationCommand 의 recommendEmergencyRooms 메서드 호출
        List<EmrRecommendDto> recommendedRooms = emrRecommendation.recommendEmergencyRooms();

        
        System.out.println("Recommended Emergency Rooms:");
        for (EmrRecommendDto room : recommendedRooms) {
            System.out.println(room.getName());
        }
        
        // 추천된 응급실 정보를 필요에 따라 추가 처리할 수 있음
        // 여기서는 요청 속성으로 설정하여 JSP 페이지에서 사용할 수 있도록 함
        request.setAttribute("recommendedRooms", recommendedRooms);

        
        // 선택적으로 요청을 JSP 페이지로 전달하여 렌더링할 수 있음
        //RequestDispatcher dispatcher = request.getRequestDispatcher("/recommendation.jsp");
        //dispatcher.forward(request, response);
    	
    }	
}
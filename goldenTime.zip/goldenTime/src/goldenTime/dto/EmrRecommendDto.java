package goldenTime.dto;

import java.util.HashMap;
import java.util.Map;

public class EmrRecommendDto {
	private String name;
	private double distance;
	private String congestion;
	
	public EmrRecommendDto(String name, double distance, String congestion) {
        this.name = name;
        this.distance = distance;
        this.congestion = congestion;
    }
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getDistance() {
		return distance;
	}
	public void setDistance(double distance) {
		this.distance = distance;
	}
	public String getCongestion() {
		return congestion;
	}
	public void setCongestion(String congestion) {
		this.congestion = congestion;
	}
	
	public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("name", this.name);
        map.put("distance", this.distance);
        map.put("congestion", this.congestion);
        return map;
    }
	
}
